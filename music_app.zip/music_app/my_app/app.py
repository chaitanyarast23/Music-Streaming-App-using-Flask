from flask import Flask, render_template, url_for, redirect,request,flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin, login_user, LoginManager, login_required, logout_user, current_user
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField,TextAreaField,FieldList,FormField,SelectMultipleField, widgets
from wtforms.validators import InputRequired, Length, ValidationError
from flask_bcrypt import Bcrypt
from sqlalchemy.exc import IntegrityError
from flask import abort
import os 
import json
from sqlalchemy import or_

app = Flask(__name__)

current_dir=os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///" + os.path.join(current_dir, "music_app.sqlite")
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)
app.config['SECRET_KEY'] = 'thisisasecretkey'


login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'


@login_manager.user_loader
def load_user(user_id):
    user = User.query.get(user_id)
    if user is None:
        user = Creators.query.get(user_id)
    
    return user

class User(db.Model, UserMixin):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    user_name = db.Column(db.String(20), nullable=False, unique=True)
    password = db.Column(db.String(80), nullable=False)

    def get_id(self):
        return str(self.id)

class MusicLibrary(db.Model):
    __tablename__ = 'music_lib'
    sr_no = db.Column(db.Integer, primary_key=True, autoincrement=True)
    title = db.Column(db.String(100), unique=True, nullable=False)
    singer = db.Column(db.String(50), nullable=False)
    release_date = db.Column(db.String(20), nullable=False)
    lyrics = db.Column(db.String(300), nullable=False)
    user_name = db.Column(db.String(30), nullable=False)
    rating = db.Column(db.Float, default=0.0)
    
    
    def get_user_rating(self, user_name):
        return UserSongRating.query.filter_by(user_name=user_name, song_id=self.sr_no).first()

class UserPlaylist(db.Model):
    __tablename__ = 'user_playlist'
    id = db.Column(db.Integer, primary_key=True)
    user_name = db.Column(db.Integer, nullable=False)
    song_id = db.Column(db.Integer, nullable=False)
    counter = db.Column(db.Integer, default=1)

class UserSongRating(db.Model):
    __tablename__ = 'user_song_ratings'
    id = db.Column(db.Integer, primary_key=True)
    user_name = db.Column(db.String(20), nullable=False)
    song_id = db.Column(db.Integer, nullable=False)
    rating = db.Column(db.Float, nullable=False)

class Album(db.Model):
    __tablename__ = 'albums'
    id = db.Column(db.Integer, primary_key=True)
    album_name = db.Column(db.String(100), nullable=False)
    title = db.Column(db.String(100), unique=True, nullable=False)
    singer = db.Column(db.String(50), nullable=False)
    release_date = db.Column(db.String(20), nullable=False)
    lyrics = db.Column(db.String(300), nullable=False)
    user_name = db.Column(db.String(30), nullable=False)
    
    

class Creators(db.Model, UserMixin):
    __tablename__ = 'creators'
    user_name = db.Column(db.String(30), primary_key=True, nullable=False, unique=True)
    password = db.Column(db.String(100), nullable=False)

    def get_id(self):
        return str(self.user_name)


class RegisterForm(FlaskForm):
    user_name = StringField(validators=[
                           InputRequired(), Length(min=4, max=20)], render_kw={"placeholder": "Username"})

    password = PasswordField(validators=[
                             InputRequired(), Length(min=8, max=20)], render_kw={"placeholder": "Password"})

    submit = SubmitField('Register')

    def validate_user_name(self, user_name):
        existing_user_username = User.query.filter_by(
            user_name=user_name.data).first()
        if existing_user_username:
            raise ValidationError(
                'That username already exists. Please choose a different one.')


class LoginForm(FlaskForm):
    user_name = StringField(validators=[
                           InputRequired(), Length(min=4, max=20)], render_kw={"placeholder": "Username"})

    password = PasswordField(validators=[
                             InputRequired(), Length(min=8, max=20)], render_kw={"placeholder": "Password"})

    submit = SubmitField('Login')

class CreatorLoginForm(FlaskForm):
    user_name = StringField(validators=[
                           InputRequired(), Length(min=4, max=20)], render_kw={"placeholder": "Username"})

    password = PasswordField(validators=[
                             InputRequired(), Length(min=8, max=20)], render_kw={"placeholder": "Password"})

    submit = SubmitField('Login')

class CreatorRegisterForm(FlaskForm):
    user_name = StringField(validators=[
                           InputRequired(), Length(min=4, max=20)], render_kw={"placeholder": "Username"})
    password = PasswordField(validators=[
                             InputRequired(), Length(min=8, max=20)], render_kw={"placeholder": "Password"})

    submit = SubmitField('Register')

    def validate_user_name(self, user_name):
        existing_creator = Creators.query.filter_by(user_name=user_name.data).first()
        if existing_creator:
            raise ValidationError('A creator with this username already exists. Please choose a different one.')

class AdminLoginForm(FlaskForm):
    username = StringField(validators=[
                           InputRequired(), Length(min=4, max=20)], render_kw={"placeholder": "Username"})

    password = PasswordField(validators=[
                             InputRequired(), Length(min=8, max=20)], render_kw={"placeholder": "Password"})

    submit = SubmitField('Login')

class EditSongForm(FlaskForm):
    title = StringField('Title', validators=[InputRequired(), Length(max=100)])
    singer = StringField('Singer', validators=[InputRequired(), Length(max=50)])
    release_date = StringField('Release Date', validators=[InputRequired(), Length(max=20)])
    lyrics = TextAreaField('Lyrics', validators=[InputRequired(), Length(max=300)])
    submit = SubmitField('Save Changes')


class AlbumForm(FlaskForm):
    album_name = StringField('Album Name', validators=[InputRequired()])
    songs = StringField('Songs (comma-separated)', validators=[InputRequired()])
    submit = SubmitField('Upload Album')

with open('config.json', 'r') as config_file:
    config_data = json.load(config_file)

admin_username = config_data.get('admin_username')
admin_password = config_data.get('admin_password')

blacklisted_users = set()
blacklisted_creators = set()


@app.route('/')
def main():
    return render_template('main.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(user_name=form.user_name.data).first()
        if user and user.user_name not in blacklisted_users:
            if bcrypt.check_password_hash(user.password, form.password.data):
                login_user(user)
                return redirect(url_for('home'))
            else:
                flash('Incorrect password. Please try again.', 'danger')
        else:
            flash('Invalid username or user is blacklisted.', 'danger')
    return render_template('login.html', form=form)

@app.route('/creator_login', methods=['GET', 'POST'])
def creator_login():
    form = CreatorLoginForm()
    if form.validate_on_submit():
        creator = Creators.query.filter_by(user_name=form.user_name.data).first()
        if creator and creator.user_name not in blacklisted_creators:
            if bcrypt.check_password_hash(creator.password, form.password.data):
                login_user(creator)
                return redirect(url_for('creator_dash'))
            else:
                flash('Incorrect password. Please try again.', 'danger')
        else:
            flash('Invalid username or creator is blacklisted.', 'danger')
    return render_template('creator_login.html', form=form)

@app.route('/admin_login', methods=['GET', 'POST'])
def admin_login():
    form = AdminLoginForm()

    if form.validate_on_submit():
        if form.username.data == admin_username and  form.password.data==admin_password:
           
            return redirect(url_for('admin_dash'))

    return render_template('admin_login.html', form=form)

@app.route('/blacklist_user/<string:user_name>')
def blacklist_user(user_name):
    user = User.query.filter_by(user_name=user_name).first()
    if user:
        blacklisted_users.add(user_name)
    return redirect(url_for('admin_dash'))

@app.route('/blacklist_creator/<string:creator_name>')
def blacklist_creator(creator_name):
    creator = Creators.query.filter_by(user_name=creator_name).first()
    if creator:
        blacklisted_creators.add(creator_name)
    return redirect(url_for('admin_dash'))


@app.route('/home',methods=['GET', 'POST'])
@login_required
def home():
    user_name = current_user.user_name if current_user.is_authenticated else None
    recommended_tracks = MusicLibrary.query.limit(3).all()
    genre_data = db.session.query(MusicLibrary.singer).distinct().limit(3).all()
    return render_template('home.html',  recommended_tracks=recommended_tracks, genre_data=genre_data)

@app.route('/search', methods=['GET'])
def search():
    query = request.args.get('query', '')
    
    search_results = MusicLibrary.query.filter(or_(MusicLibrary.title.ilike(f'%{query}%'), MusicLibrary.singer.ilike(f'%{query}%'))).all()

    return render_template('search_results.html', query=query, search_results=search_results)

@app.route('/song/<int:song_id>')
def view_song(song_id):
    
    song = MusicLibrary.query.get(song_id)
    return render_template('view_song.html', song=song)

@app.route('/see_more')
def see_more():
    
    additional_tracks = MusicLibrary.query.offset(3).limit(9).all()
    
    return render_template('see_more.html', additional_tracks=additional_tracks)

@app.route('/genre_see_more')
def genre_see_more():
    
    all_genres = db.session.query(MusicLibrary.singer).distinct().all()

    return render_template('genre_see_more.html', all_genres=all_genres)

@app.route('/add_to_playlist/<int:song_id>', methods=['GET', 'POST'])
@login_required
def add_to_playlist(song_id):
    
    user = User.query.filter_by(user_name=current_user.user_name).first()
    song = MusicLibrary.query.get(song_id)

    user_playlist_entry = UserPlaylist.query.filter_by(user_name=user.user_name, song_id=song.sr_no).first()

    if user_playlist_entry:
    
        return redirect(url_for('view_song', song_id=song_id))
    else:
        
        user_playlist_entry = UserPlaylist(user_name=user.user_name, song_id=song.sr_no, counter=1)
        db.session.add(user_playlist_entry)
        db.session.commit()

    
    return redirect(url_for('view_song', song_id=song_id))

@app.route('/playlist', methods=['GET', 'POST'])
@login_required
def playlist():
    
    user = User.query.filter_by(user_name=current_user.user_name).first()

    user_playlist_entries = UserPlaylist.query.filter_by(user_name=user.user_name).all()

    playlist_songs = []

    for entry in user_playlist_entries:
        song_id = entry.song_id
        song = MusicLibrary.query.get(song_id)
        if song:
            playlist_songs.append(song)

    return render_template('playlist.html', playlist=playlist_songs)

@app.route('/rate_song/<int:song_id>', methods=['POST'])
@login_required
def rate_song(song_id):
    song = MusicLibrary.query.get(song_id)
    
    # Check if the user has already rated this song
    existing_rating = UserSongRating.query.filter_by(user_name=current_user.user_name, song_id=song.sr_no).first()
    
    if existing_rating:
        flash('You have already rated this song.', 'warning')
    else:
        # Get the rating from the form submission
        rating = float(request.form.get('rating'))

        # Update the song's overall rating
        song.rating = (song.rating + rating) / 2  # You can customize the rating algorithm as needed

        # Save the user's rating for this song
        user_rating = UserSongRating(user_name=current_user.user_name, song_id=song.sr_no, rating=rating)
        db.session.add(user_rating)

        # Commit changes to the database
        db.session.commit()

        flash('Song rated successfully!', 'success')

    return redirect(url_for('view_song', song_id=song_id))


@app.route('/songs_by_singer/<string:singer>')
def songs_by_singer(singer):

    songs_by_singer = MusicLibrary.query.filter_by(singer=singer).all()

    return render_template('songs_by_singer.html', singer=singer, songs_by_singer=songs_by_singer)

@app.route('/creator')
def creator():
    return render_template('creator.html')


@app.route('/creator_dash')
def creator_dash():

    user = Creators.query.filter_by(user_name=current_user.user_name).first()

    creator_songs = MusicLibrary.query.filter_by(user_name=user.user_name).all()
    creator_albums = Album.query.filter_by(user_name=user.user_name).all()

    total_songs_uploaded = len(creator_songs)
    total_albums_uploaded = len(creator_albums)

    return render_template('creator_dash.html', creator_songs=creator_songs, creator_albums=creator_albums, total_songs_uploaded=total_songs_uploaded, total_albums_uploaded=total_albums_uploaded)

@app.route('/admin_dash')
def admin_dash():

    num_normal_users = User.query.count()

    num_creators = Creators.query.count()

    songs_data = MusicLibrary.query.all()

    creators_data=User.query.all()

    users_data=Creators.query.all()

    total_tracks = len(songs_data)

    return render_template('admin_dash.html', num_normal_users=num_normal_users, num_creators=num_creators, songs_data=songs_data, total_tracks=total_tracks, creators_data=creators_data, users_data=users_data)

    
@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        title = request.form.get('title')
        singer = request.form.get('singer')
        release_date = request.form.get('release_date')
        lyrics = request.form.get('lyrics')
        user_name = request.form.get('user_name') 

        try:
            
            song = MusicLibrary(title=title, singer=singer, release_date=release_date, lyrics=lyrics, user_name=user_name)
            db.session.add(song)
            db.session.commit()

            return redirect(url_for('creator_dash'))  

        except IntegrityError:
            db.session.rollback()  

    return render_template('upload.html')


@app.route('/upload_album', methods=['GET', 'POST'])
@login_required
def upload_album():
    form = AlbumForm()

    if form.validate_on_submit():
        # Fetch song details based on the manually entered titles
        selected_titles = [title.strip() for title in form.songs.data.split(',')]
        songs = MusicLibrary.query.filter(MusicLibrary.title.in_(selected_titles)).all()

        if songs:
            # Create an album with the fetched song details
            album = Album(
                album_name=form.album_name.data,
                title=", ".join([song.title for song in songs]),  # Combine titles into a string
                singer=songs[0].singer,  # Assuming all songs in an album have the same singer
                release_date=songs[0].release_date,  # Assuming all songs in an album have the same release date
                lyrics=songs[0].lyrics,  # Assuming all songs in an album have the same lyrics
                user_name=current_user.user_name,
            )

            # Commit changes to the database
            db.session.add(album)
            db.session.commit()

            flash('Album uploaded successfully!', 'success')
            return redirect(url_for('creator_dash'))
        else:
            flash('One or more songs with the provided titles not found.', 'danger')

    return render_template('upload_album.html', form=form)


# Add a new route in your Flask app
@app.route('/edit_song/<int:song_id>', methods=['GET', 'POST'])
@login_required
def edit_song(song_id):
    song = MusicLibrary.query.get(song_id)

    # Check if the current user has permission to edit the song
    if current_user.is_authenticated and song.user_name == current_user.user_name:
        form = EditSongForm(obj=song)
        
        if form.validate_on_submit():
            # Update the song details based on the form data
            song.title = form.title.data
            song.singer = form.singer.data
            song.release_date = form.release_date.data
            song.lyrics = form.lyrics.data

            db.session.commit()

            flash('Song updated successfully!', 'success')
            return redirect(url_for('creator_dash'))

        return render_template('edit_song.html', form=form, song=song)
    else:
        abort(403)  # Return forbidden status if the user does not have permission


@app.route('/delete_song/<int:song_id>', methods=['GET', 'POST'])
@login_required
def delete_song(song_id):
    song = MusicLibrary.query.get(song_id)
     
    db.session.delete(song)
    db.session.commit()
        
    return redirect(url_for('creator_dash'))

@app.route('/delete_admin_song/<int:song_id>', methods=['GET', 'POST'])

def delete_admin_song(song_id):
    song = MusicLibrary.query.get(song_id)
    
    db.session.delete(song)
    db.session.commit()
 
    return redirect(url_for('admin_dash'))
    

@app.route('/logout', methods=['GET', 'POST'])
@login_required
def logout():
    logout_user()
    return redirect(url_for('main'))

@app.route('/admin_logout', methods=['GET', 'POST'])
def admin_logout():
    
    return redirect(url_for('main'))


@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()

    if form.validate_on_submit():
        hashed_password = bcrypt.generate_password_hash(form.password.data)
        new_user = User(user_name=form.user_name.data, password=hashed_password)
        db.session.add(new_user)
        db.session.commit()
        return redirect(url_for('login'))

    return render_template('register.html', form=form)

@app.route('/creator_registration', methods=['GET', 'POST'])
def creator_register():
    form = CreatorRegisterForm()

    if form.validate_on_submit():
        hashed_password = bcrypt.generate_password_hash(form.password.data)
        new_user = Creators(user_name=form.user_name.data, password=hashed_password)
        db.session.add(new_user)
        db.session.commit()
        return redirect(url_for('creator_login'))

    return render_template('creator_registration.html', form=form)

if __name__ == "__main__":
    app.run(debug=True)
